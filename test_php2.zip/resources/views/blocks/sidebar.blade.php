<div class="d-flex flex-column p-3 text-white bg-dark" style="height: 100vh;">
    <ul class="nav nav-pills flex-column mb-auto">
        <li class="nav-item">
            <a href="{{ route('admin') }}" class="nav-link text-white">
                <i class="fas fa-tachometer-alt"></i> Dashboard
            </a>
        </li>
        <li>
            <a href="{{ route('products') }}" class="nav-link text-white">
                <i class="fas fa-box"></i> Quản lý sản phẩm
            </a>
        </li>
    </ul>
</div>
