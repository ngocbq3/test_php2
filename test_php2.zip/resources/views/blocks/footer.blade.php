<footer class="bg-light text-center p-3 mt-4">
    <p class="mb-0">&copy; 2025 Admin Panel. All Rights Reserved.</p>
</footer>
