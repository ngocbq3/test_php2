<?php
//Đường dẫn website
const APP_URL = "http://localhost/test_php2/";
//Thư mục gốc
const APP_DIR = __DIR__;

//Database
const HOST = "localhost";
const DBNAME = "";
const USERNAME = "root";
const PASSWORD = "";
const PORT = 3306;
